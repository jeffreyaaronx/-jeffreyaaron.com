/*-----------------------------------------------------------
* Template Name    : Adams - Creative Designer
* Author           : gtomdesign
* Version          : 1.0
* Created          : Aug 2020
* File Description : Main Js file of the template
*------------------------------------------------------------
*/

! function($) {
    "use strict";

    /* ---------------------------------------------- /*
    * Preloader
    /* ---------------------------------------------- */

    $(window).on('load', function() {
        $('#preloader').addClass("loaded");
    });

    /* ---------------------------------------------- /*
    * Section Scroll - Navbar
    /* ---------------------------------------------- */
    

    $('.navbar-toggler').on('click', function(){
        $("body").toggleClass('aside-open');
        $(".ham").toggleClass('active');
        $("body, html").toggleClass('overflow-hidden');
    });

    $('.navbar-nav a').on('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top - 0
        }, 1000);

        event.preventDefault();
    });

    /* ---------------------------------------------- /*
    * Scroll Spy - init
    /* ---------------------------------------------- */

    $("#navbarCollapse").scrollspy({
        offset:20
    });

    /* ---------------------------------------------- /*
    * Swipper - Init
    /* ---------------------------------------------- */

    // Testimony init

    var swipertest = new Swiper('.swiper-testimony', {
        spaceBetween: 30,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });


    /* ---------------------------------------------- /*
    * Initialize shuffle plugin
    /* ---------------------------------------------- */

    var $portfolioContainer = $('.list-items-container');

    $('#filter li').on('click', function (e) {
        e.preventDefault();

        $('#filter li').removeClass('active');
        $(this).addClass('active');

        var group = $(this).attr('data-group');
        var groupName = $(this).attr('data-group');

        $portfolioContainer.shuffle('shuffle', groupName );
    });

    
    /* ---------------------------------------------- /*
    * Parallax - Init
    /* ---------------------------------------------- */


    if($(".parallaxDefault").length) {
        var parallaxDefault = document.getElementsByClassName('parallaxDefault');
        new simpleParallax(parallaxDefault, {
            scale: 1.2,
            orientation: "down",
            delay: .6,
            transition: 'cubic-bezier(0,0,0,1)'
        });
    }

    if($(".parallaxLeft").length) {
        var parallaxLeft = document.getElementsByClassName('parallaxLeft');
        new simpleParallax(parallaxLeft, {
            scale: 1.2,
            orientation: "left",
            delay: .6,
            transition: 'cubic-bezier(0,0,0,1)'
        });
    }

    if($(".parallaxRight").length) {
        var parallaxRight = document.getElementsByClassName('parallaxRight');
        new simpleParallax(parallaxRight, {
            scale: 1.2,
            orientation: "right",
            delay: .6,
            transition: 'cubic-bezier(0,0,0,1)'
        });
    }


    /* ---------------------------------------------- /*
    * Typed init
    /* ---------------------------------------------- */

    if($('.typed').length) {
        var $this = $(".typed");
        $this.typed({
            strings: $this.attr('data-elements').split(','),
            typeSpeed: 100,
            backDelay: 3000
        });
    }


}(window.jQuery);

